package com.psl.client;

import com.psl.beans.Customer;
import com.psl.beans.OrderItem;
import com.psl.beans.StockItem;
import com.psl.beans.Units;
import com.psl.dao.ConnectionManagerImpl;
import com.psl.utility.PurchaseOrderManagerImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Client {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {

		PurchaseOrderManagerImpl impl = new PurchaseOrderManagerImpl();
		//(1)
		//List<Customer> l1 = impl.populateCustomers();
		
		//(2)
		//List<StockItem> l2 = impl.populateStoreItems();
		
		//(3)
		/*
		ArrayList<OrderItem>orderItems = new ArrayList<OrderItem>();
		
		ConnectionManagerImpl c = new ConnectionManagerImpl();
		try {
		
		Connection con = c.getDBConnection("jdbc:mysql://localhost:3306/ordermgmtdb", "root", "");
		
		String query = "select * from ordereditem_details;";
		Statement statement = con.createStatement();
		
		ResultSet rs =  statement.executeQuery(query);
		
		while(rs.next())
		{
			OrderItem o;
			
				o = new OrderItem(rs.getInt(1),rs.getInt(2),rs.getInt(3));
			
			orderItems.add(o);
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date parsed = sdf.parse("2017-01-10");
       
        //function call
        impl.createOrder(1003, orderItems, parsed); 
        impl.createOrder(1004, orderItems, parsed); 
        impl.createOrder(1005, orderItems, parsed); 
		
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		c.closeConnection();
		*/
		
		
		//(4)
		//impl.storePurchaseOrder();
		
		//(5)
		impl.shipOrders(1001);
		
		//(6)
		//impl.removeExpiredItems();
		
		//(7)
		//impl.showItems();
		
		//(8)
		//impl.applyDiscountOnItems();
		
		//(9)
		//impl.getOrdersByCustomer();
		
		//(10)
		//impl.displayDiscountedItemsList();
	}

}
