package com.psl.utility;

import java.util.Comparator;
import java.util.Date;

import com.psl.beans.StockItem;

public class DateComparator implements Comparator<StockItem>{

	@Override
	public int compare(StockItem o1, StockItem o2) {
		Date d1 = o1.getBestBefore();
		Date d2 = o2.getBestBefore();
		return d1.compareTo(d2);
	}

}
