package com.psl.utility;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import com.psl.beans.Address;
import com.psl.beans.Customer;
import com.psl.beans.OrderItem;
import com.psl.beans.PurchaseOrder;
import com.psl.beans.StockItem;
import com.psl.beans.Units;
import com.psl.dao.ConnectionManagerImpl;

public class PurchaseOrderManagerImpl implements PurchaseOrderManager{

	@Override
	public List<Customer> populateCustomers() {
		
		List<Customer>customers = new ArrayList<Customer>();
		
		ConnectionManagerImpl c = new ConnectionManagerImpl();
		
		Connection con = c.getDBConnection("jdbc:mysql://localhost:3306/ordermgmtdb", "root", "");
		
		/*
		// TODO Auto-generated method stub
		try{
		BufferedReader br = new BufferedReader(new FileReader("customers.txt"));
			StringBuffer sb = new StringBuffer();
			
			String line=null;
			String msg=null;
			try {
				while((line=br.readLine())!=null)
				{
					String m[]=line.split(",");
					String addr = m[2]+"," + m[3] + "," + m[4] + "," + m[5];
					String query1 = "insert into customer_details value("+Integer.valueOf(m[0])+",'"+m[1]+"','"+addr+"','"+m[6]+"'"+")";
					
					Statement s = con.createStatement();
					s.executeUpdate(query1);
				}
								
			} catch (IOException e) {
				
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		}
		*/
		
		
		try {
			List<PurchaseOrder>lp = new ArrayList<PurchaseOrder>();
			
			String query2 = "select * from purchaseorder_details;";
			Statement stmt = con.createStatement();
			
			ResultSet rset =  stmt.executeQuery(query2);
			while(rset.next())
			{
				PurchaseOrder order = new PurchaseOrder(rset.getInt(1),rset.getDate(2),rset.getDate(3));
				lp.add(order);
			}
			
		
		String query3 = "select * from customer_details;";
		Statement statement = con.createStatement();
		
		ResultSet rs =  statement.executeQuery(query3);
		
		while(rs.next())
		{
			String s[] = rs.getString(3).split(",");
			Address a = new Address(s[0],s[1],s[2],Integer.valueOf(s[3]));
			
			Customer cust = new Customer(rs.getInt(1),rs.getString(2),a,rs.getString(4),lp);
			customers.add(cust);
		}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		c.closeConnection();
				
		return customers;
	}

	@Override
	public List<StockItem> populateStoreItems() {
		
		ConnectionManagerImpl c = new ConnectionManagerImpl();
		
		Connection con = c.getDBConnection("jdbc:mysql://localhost:3306/ordermgmtdb", "root", "");
		
		/*
		try{
		BufferedReader br = new BufferedReader(new FileReader("stockitems.txt"));
			StringBuffer sb = new StringBuffer();
			
			String line=null;
			String msg=null;
			try {
				while((line=br.readLine())!=null)
				{
					String m[]=line.split(",");
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			        Date parsed = sdf.parse(m[5]);
			        java.sql.Date sql1 = new java.sql.Date(parsed.getTime());
			        parsed = sdf.parse(m[6]);
			        java.sql.Date sql2 = new java.sql.Date(parsed.getTime());
			        
					String query1 = "insert into stockitem_details value("+Integer.valueOf(m[0])+",'"+m[1]+"','"+m[2]+"','"+m[3]+"',"+Integer.valueOf(m[4])+",'"+sql1+"','"+sql2+"')";              
					
					Statement s = con.createStatement();
					s.executeUpdate(query1);
				}
								
			} catch (IOException e) {
				
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		}
		*/
		List<StockItem> stockItems = new ArrayList<StockItem>();
		try{
		
		String query2 = "select * from stockitem_details;";
		Statement statement = con.createStatement();
		
		ResultSet rs =  statement.executeQuery(query2);
		
		while(rs.next())
		{
			StockItem s = new StockItem(rs.getInt(1),rs.getString(2),rs.getString(3),Units.valueOf(rs.getString(4)),rs.getInt(5),rs.getDate(6),rs.getDate(7));
			stockItems.add(s);
		}
		
		} catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		
		c.closeConnection();
		return stockItems;
	}

	@Override
	public void createOrder(int cust_id, ArrayList<OrderItem> OrderedItems, Date ship_date) 
	{
		PurchaseOrder order = new PurchaseOrder();
		Date date=Calendar.getInstance().getTime();
		
		order.setOrderNo(OrderedItems.get(0).getOrderno());
		order.setOrderDate(date);
		
		if(ship_date==null)
		{
			Date sdate=new Date();
			Calendar c = Calendar.getInstance(); 
			c.setTime(sdate); 
			c.add(Calendar.DATE, 6);
			sdate = c.getTime();
		}
		else
		{
			order.setShipdate(ship_date);
		}
		
	}

	@Override
	public void storePurchaseOrder() {
		ConnectionManagerImpl c = new ConnectionManagerImpl();
		
		Connection con = c.getDBConnection("jdbc:mysql://localhost:3306/ordermgmtdb", "root", "");
		
		try {
			List<PurchaseOrder>lp = new ArrayList<PurchaseOrder>();
			
			String query2 = "select * from purchaseorder_details;";
			Statement stmt = con.createStatement();
			
			ResultSet rset =  stmt.executeQuery(query2);
			while(rset.next())
			{
				PurchaseOrder order = new PurchaseOrder(rset.getInt(1),rset.getDate(2),rset.getDate(3));
				lp.add(order);
			}
			
			try (
					ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("PoNo_99.ser"))) {

				for(PurchaseOrder po : lp)
				{
					oos.writeObject(po);
				}
				
			} catch (Exception ex) {
				ex.printStackTrace();
			}
					
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		
		c.closeConnection();
				
	}

	@Override
	public void shipOrders(int cust_id) {
		
		/*
		Path path = Paths.get("C:\\Users\\Administrator\\Documents\\alinda-mpc\\CustomerBills\\bills_date\\customerId");
		
		if (!Files.exists(path)) {
		    try {
		        Files.createDirectories(path);
		    } catch (IOException e) {
		      
		        e.printStackTrace();
		    }
		}
	*/
		try {
			PrintWriter pw = new PrintWriter(new File ("C:/Users/Administrator/Documents/alinda-mpc/CustomerBills/bills_date/customerId/custname_date_poNo.txt"));
			
			ConnectionManagerImpl c = new ConnectionManagerImpl();
			
			Connection con = c.getDBConnection("jdbc:mysql://localhost:3306/ordermgmtdb", "root", "");
			
			String query = "select from customer_details where id="+cust_id;
			
			Statement s = con.createStatement();
			
			ResultSet rs = s.executeQuery(query);
			while(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				
			}
		} catch (FileNotFoundException e) {


			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public Void removeExpiredItems() {
		ConnectionManagerImpl c = new ConnectionManagerImpl();
		
		Connection con = c.getDBConnection("jdbc:mysql://localhost:3306/ordermgmtdb", "root", "");
		
		try {
			List<StockItem> stockItems = new ArrayList<StockItem>();
						
			String query2 = "select * from stockitem_details;";
			Statement statement = con.createStatement();
			
			ResultSet rs =  statement.executeQuery(query2);
			
			while(rs.next())
			{
				StockItem s = new StockItem(rs.getInt(1),rs.getString(2),rs.getString(3),Units.valueOf(rs.getString(4)),rs.getInt(5),rs.getDate(6),rs.getDate(7));
				Calendar cal = Calendar.getInstance();
				cal.setTime(rs.getDate(7));
				
				if(!Calendar.getInstance().after(cal))
				{
					stockItems.add(s);
					
				}
				else
				{
					String query3 = "delete from customer_order_details where order_no IN (select orderno from ordereditem_details where id="+rs.getInt(1)+");";
					String query4 = "delete from ordereditem_details where id="+rs.getInt(1)+";";
					String query5 = "delete from stockitem_details where Best_before_date='"+rs.getDate(7)+"';";
					Statement stat = con.createStatement();
					
					//stat.addBatch(query3);
					stat.addBatch(query4);
					stat.addBatch(query5);
					
					stat.executeBatch();
					
				}
				
			}
			
			for(StockItem si : stockItems)
			{
				System.out.println(si.toString());
				System.out.println("****************************************************************************");
			}
					
		}	
		catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
			
		 catch (Exception ex) {
			ex.printStackTrace();
		}
		
		c.closeConnection();
				
		return null;
	}

	@Override
	public Void showItems() {
		
		ConnectionManagerImpl c = new ConnectionManagerImpl();
		
		Connection con = c.getDBConnection("jdbc:mysql://localhost:3306/ordermgmtdb", "root", "");
		
		try {
			List<StockItem> stockItems = new ArrayList<StockItem>();
			
			String query2 = "select * from stockitem_details;";
			Statement statement = con.createStatement();
			
			ResultSet rs =  statement.executeQuery(query2);
			
			while(rs.next())
			{
				StockItem s = new StockItem(rs.getInt(1),rs.getString(2),rs.getString(3),Units.valueOf(rs.getString(4)),rs.getInt(5),rs.getDate(6),rs.getDate(7));
				stockItems.add(s);
			}
			
			Date d = stockItems.get(0).getBestBefore();
			for(StockItem si : stockItems)
			{
				
			}
				 
			Collections.sort(stockItems, new DateComparator());
						
			System.out.println("All Items :");
			System.out.println("****************************************************************************");
			System.out.println("");
			for(StockItem si : stockItems)
			{
				System.out.println(si.toString());
				System.out.println("****************************************************************************");
			}
					
		}	
		catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
			
		 catch (Exception ex) {
			ex.printStackTrace();
		}
		
		c.closeConnection();
			return null;
	}

	@Override
	public Void applyDiscountOnItems() {
		
		ConnectionManagerImpl c = new ConnectionManagerImpl();
		
		Connection con = c.getDBConnection("jdbc:mysql://localhost:3306/ordermgmtdb", "root", "");
		
		try {
			
			String query2 = "select * from stockitem_details;";
			Statement statement = con.createStatement();
			
			ResultSet rs =  statement.executeQuery(query2);
			
			while(rs.next())
			{
				Date d = new Date();
				Calendar cal = Calendar.getInstance(); 
				cal.setTime(d); 
				cal.add(Calendar.MONTH, 2);
				
				if(rs.getDate(7).before(cal.getTime()))
				{
					//apply 40% discount on items
					int disc = (int)(rs.getInt(5)-(0.4 * rs.getInt(5)));
					String q = "update stockitem_details set `price per unit` = "+disc+" where id="+rs.getInt(1);
					
					Statement s = con.createStatement();
					s.executeUpdate(q);
				}
			}
				
		}	
		catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
			
		 catch (Exception ex) {
			ex.printStackTrace();
		}
		
		c.closeConnection();
			
		return null;
	}

	@Override
	public Map<Customer, ArrayList<PurchaseOrder>> getOrdersByCustomer() {
		//Returns all customers along with list of purchase Orders placed by him.

		Map<Customer, ArrayList<PurchaseOrder>> map = new HashMap<Customer, ArrayList<PurchaseOrder>>();
		
		List<Customer>customers = new ArrayList<Customer>();
		
		ConnectionManagerImpl c = new ConnectionManagerImpl();
		
		Connection con = c.getDBConnection("jdbc:mysql://localhost:3306/ordermgmtdb", "root", "");
		
		try {
			List<PurchaseOrder>lp = new ArrayList<PurchaseOrder>();
			
			String query2 = "select * from purchaseorder_details;";
			Statement stmt = con.createStatement();
			
			ResultSet rset =  stmt.executeQuery(query2);
			while(rset.next())
			{
				PurchaseOrder order = new PurchaseOrder(rset.getInt(1),rset.getDate(2),rset.getDate(3));
				lp.add(order);
			}
			
		String query3 = "select * from customer_details;";
		Statement statement = con.createStatement();
		
		ResultSet rs =  statement.executeQuery(query3);
		
		while(rs.next())
		{
			String s[] = rs.getString(3).split(",");
			Address a = new Address(s[0],s[1],s[2],Integer.valueOf(s[3]));
			
			Customer cust = new Customer(rs.getInt(1),rs.getString(2),a,rs.getString(4),lp);
			customers.add(cust);
		}
		
		String query4 = "select * from customer_order_details;";
		Statement st = con.createStatement();
		
		ResultSet res =  st.executeQuery(query4);
		Map<Integer,Integer> ord = new HashMap<>();
		while(res.next())
		{
			ord.put(res.getInt(1),res.getInt(2));
		}
		
		for(Customer cu : customers)
		{
			ArrayList<PurchaseOrder> pList = new ArrayList<PurchaseOrder>();
			for(PurchaseOrder pu : lp)
			{
				if(ord.get(cu.getId())==pu.getOrderNo())
				{
					pList.add(pu);
				}
			}
			map.put(cu,pList);
		}
		
		for(Map.Entry<Customer, ArrayList<PurchaseOrder>> e : map.entrySet())
		{
			System.out.println(e.getKey());
			System.out.println(e.getValue());
			System.out.println("");
		}
		
		} catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		c.closeConnection();
				
		return null;
	}

	@Override
	public Void displayDiscountedItemsList() {
		ConnectionManagerImpl c = new ConnectionManagerImpl();
		
		Connection con = c.getDBConnection("jdbc:mysql://localhost:3306/ordermgmtdb", "root", "");
		
		try {
			
			String query2 = "select * from stockitem_details;";
			Statement statement = con.createStatement();
			
			ResultSet rs =  statement.executeQuery(query2);
			
			System.out.println("Discounted Items :");
			System.out.println("****************************************************************************");
			System.out.println("");
			while(rs.next())
			{
				Date d = new Date();
				Calendar cal = Calendar.getInstance(); 
				cal.setTime(d); 
				cal.add(Calendar.MONTH, 2);
				
				if(rs.getDate(7).before(cal.getTime()))
				{
					System.out.println("****************************************************************************");
					
					System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getInt(5)+" "+rs.getDate(6)+" "+rs.getDate(7));
				}
			}
				
		}	
		catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
			
		 catch (Exception ex) {
			ex.printStackTrace();
		}
		
		c.closeConnection();
			
		return null;
	}

}
