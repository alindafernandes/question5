package com.psl.dao;

import java.util.ArrayList;
import java.util.Date;

import com.psl.beans.Customer;
import com.psl.beans.OrderItem;
import com.psl.beans.PurchaseOrder;

public class PurchaseOrderManagerDB {
	public boolean insertOrderItem(OrderItem o)
	{
		return false;
		
	}
	public boolean insertPurchaseOrder(PurchaseOrder p)
	{
		return false;
		
	}
	public Boolean insertcustomerOrder(int a,int b)
	{
		return null;
		
	}
	public ArrayList<PurchaseOrder> getAllOrdersByCustomer(int cust_id)
	{
		return null;
	//Return all orders placed by customer	
	}

	public ArrayList<PurchaseOrder> ordersToBeShipped(Date fromdate, Date todate)
	{
		return null;
		//Return all orders to be shipped in specified duration.
	}

	public void deletePurchaseOrder(int orderno) 
	{
		//delete purchase orders
	}

	public void deleteOrderItem(int orderno)
	{
		//delete OrderItems
	}

	public void insertShippedOrders(Customer cust_no,ArrayList PurchaseOrder,ArrayList orderItems,String PersonName)
	{
		//Inserts data into shipped_order_details
	}
}
