package com.psl.dao;

import java.util.ArrayList;

import com.psl.beans.StockItem;

public class StockItemManagerDB {
	public Void insertStockItems(ArrayList StockItem)
	{
		return null;
		//Inserts Stock Items details into data base
	}
	
	public ArrayList<StockItem> getStockItems()
	{
		return null;
		//Return StockItems List
	}
	void deleteStockItems(int no) 
	{
		//delete stockItems
	}

}
