package com.psl.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class ConnectionManagerImpl implements ConnectionManager {

	public Connection con = null;
	
	@Override
	public Connection getDBConnection(String url, String user, String pwd) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url, user, pwd);
			//
			
			//Statement s = con.createStatement();
			
			//String query = "create table emp ( EMPNO int(4) not null,ENAME varchar(10), JOB varchar(9), MGR int(4), HIREDATE date,SAL double(7,2),COMM double(7,2),DEPTNO int(2))";  
			
			//s.execute(query);
						
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return con;
	}

	@Override
	public void closeConnection() {
		try{
			con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}

	
}
