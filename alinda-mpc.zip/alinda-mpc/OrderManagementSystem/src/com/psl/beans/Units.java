package com.psl.beans;

public enum Units {
	kg, gallon,grams,nos;
}
