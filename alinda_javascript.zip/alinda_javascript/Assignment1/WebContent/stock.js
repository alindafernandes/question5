
var stock=new Object();

stock={
		name: "Persistent",
		price: 750,
		advice: "Buy",
		description: "IT Company",
		setprice: function(pr){
			this.price=pr;
		},
		setadvice: function(ad){
			this.advice=ad;
		},
		getprice: function()
		{
			return this.price;
		},
		getadvice: function()
		{
			return this.advice;
		}
}

console.log(stock);

stock.setprice(1000);
stock.setadvice("don't buy");

console.log(stock);