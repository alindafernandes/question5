/*Q9.	Write a JavaScript program to display the current day and time in the following format.
Today is: Friday. 
Current time is: 2 PM: 44: 22
HINT: use Date object from the javascript and use functions like
getDay(), getHours(), getMinutes(), getSeconds();
Maintain one array of day as [Sunday, Monday]
*/

date=new Date();

var day=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
var d=day[date.getDay()];
console.log("Today is: "+d);
console.log("Current time is: "+date.getHours() +" : "+date.getMinutes()+" : "+date.getSeconds());
