var a=parseInt(prompt("enter number"));

function isPrime(a)
{
	var x=a-1;
	while(x>1)
		{
			if((a%x)==0)
				return false;
			x--;
		}
	if(a==1)
		return false;
	else
		return true;
}

if(isPrime(a))
	alert(a+" is Prime");
else
	alert(a+" is not Prime");