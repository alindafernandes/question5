
function random()
{
	var ran=Math.floor((Math.random()*50)+1);
	return ran;
}

console.log(random());
