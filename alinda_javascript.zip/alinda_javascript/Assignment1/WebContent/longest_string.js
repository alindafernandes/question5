
function longest(str)
{
	arr=str.split(" ");
	max="";
	arr.forEach(function(word){
	
		if(word.length > max.length)
			max=word;
	});
	return max;
}

var str="this is a string.";
console.log(str);
console.log("longest word in the above sentence : "+longest(str));