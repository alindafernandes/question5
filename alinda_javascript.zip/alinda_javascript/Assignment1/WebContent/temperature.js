
function toCelcius(f)
{
	return ((f-32)*5/9);
}

function toFarenheit(c)
{
	return (((c*9)/5)+32);
}

var c=Number(prompt("enter temperature in celcius"));
var f=Number(prompt("enter temperature in Farenheit"));

console.log(c+" C is "+toFarenheit(c)+" F");
console.log(f+" F is "+toCelcius(f)+" C");
