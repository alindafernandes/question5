
function duplicate(arr)
{
	var sorted_arr = arr.slice().sort();
	var results = [];
	for (var i = 0; i < arr.length - 1; i++) {
	    if (sorted_arr[i + 1] == sorted_arr[i]) {
	        results.push(sorted_arr[i]);
	    }
	}
	return results;
}

var arr=new Array("10","11","7","6","10","23","6","10");
console.log("duplicate values are : "+duplicate(arr));