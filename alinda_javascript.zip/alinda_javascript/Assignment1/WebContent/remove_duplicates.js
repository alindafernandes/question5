
var arr1=[10,3,89,45,2,3];
var arr2=[45,7,1,6,3,12];

var arr=arr1.concat(arr2);

console.log(eliminateDuplicates(arr));


function eliminateDuplicates(arr) {
	  var i;
	  var len=arr.length;
	  var out=[];
	  var obj={};

	  for (i=0;i<len;i++) {
	    obj[arr[i]]=0;
	  }
	  for (i in obj) {
	    out.push(i);
	  }
	  return out;
	}



