var library = [ 
   {
       author: 'Bill Gates',
       title: 'The Road Ahead',
       readingStatus: true
   },
   {
       author: 'Walter Isaacson ',
       title: 'Steve Jobs',
       readingStatus: true
   },
   {
       author: 'Randy Pauch',
       title:  'The Last Lecture', 
       readingStatus: false
   }];

for(var l in library)
{
	if(library[l].readingStatus)
		{
		console.log("Already read");
		}
	else
		console.log("You still need to read");
	console.log(library[l]);
}