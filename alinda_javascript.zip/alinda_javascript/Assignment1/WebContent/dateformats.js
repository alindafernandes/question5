/*Write a JavaScript program to get the current date and show the same in following formats
mm-dd-yyyy, 
mm/dd/yyyy, 
dd-mm-yyyy, 
dd/mm/yyyy
*/

var d = new Date();
console.log(d.getMonth()+"-"+d.getDate()+"-"+d.getFullYear());
console.log(d.getMonth()+"/"+d.getDate()+"/"+d.getFullYear());
console.log(d.getDate()+"-"+d.getMonth()+"-"+d.getFullYear());
console.log(d.getDate()+"/"+d.getMonth()+"/"+d.getFullYear());
