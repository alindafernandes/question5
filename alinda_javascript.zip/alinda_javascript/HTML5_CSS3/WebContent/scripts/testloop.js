
		for(var i=0;i<100000000;i++){
			var no=i
		}	
postMessage(c);