package com.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import com.bean.Show;
import com.exception.InvalidSeatNumberException;
import com.exception.SeatsNotAvailableException;
import com.exception.UnknownShowException;

//Override and implement all the methods of DataManger Interface in this class


public class DataManagerImpl implements DataManager {

	private static List<Show> list = new ArrayList<Show>();
	
	public List<Show> populateDataFromFile(String fileName) {
		
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName));
			
			Show s = (Show) ois.readObject();
				
			list.add(s);
			for(Show st : list)
			{
				System.out.println(st);
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	public void bookShow(List<Show> showList, String showName,
			String show_time, int noOfSeats) throws SeatsNotAvailableException,
			UnknownShowException, InvalidSeatNumberException {
		int count = 0;
		
		for(Show st : list)
		{
			if(showName.compareTo(st.getShowName())==0)
			{
				count++;
				if(noOfSeats>st.getSeatsAvailable())
					throw new SeatsNotAvailableException();
			}	
		}
		
		if(count==0)
			throw new UnknownShowException();
		
		
		if(noOfSeats<=0)
			throw new InvalidSeatNumberException();
		
	}
	
}
