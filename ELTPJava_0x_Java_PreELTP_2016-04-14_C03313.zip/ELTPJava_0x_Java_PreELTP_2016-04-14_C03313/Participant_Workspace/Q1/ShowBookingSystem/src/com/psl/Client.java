package com.psl;

import java.util.List;

import com.bean.Show;
import com.exception.InvalidSeatNumberException;
import com.exception.SeatsNotAvailableException;
import com.exception.UnknownShowException;
import com.util.DataManagerImpl;

public class Client {
	
	public static void main(String[] args) {
		
		DataManagerImpl impl = new DataManagerImpl();
		
		List<Show> list = impl.populateDataFromFile("ShowDetails.ser");
		
		try {
			impl.bookShow(list, "Sahi re Sahi", "6:30", 4);
			
			impl.bookShow(list, "Sahi re Sahi", "6:30", -1);
			
			impl.bookShow(list, "Sahi re Sahi", "6:30", 48);
					
			impl.bookShow(list, "cartoon", "6:30", 4);
			
		} catch (SeatsNotAvailableException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnknownShowException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidSeatNumberException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
