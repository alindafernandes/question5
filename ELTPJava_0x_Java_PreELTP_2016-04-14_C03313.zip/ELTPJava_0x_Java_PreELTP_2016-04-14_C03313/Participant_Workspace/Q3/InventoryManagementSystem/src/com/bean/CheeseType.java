package com.bean;

public enum CheeseType {
	Mozzarella ,Easy_Spread,Cottage,Cheddar
}
