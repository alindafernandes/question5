package com.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import com.bean.Cheese;
import com.bean.CheeseType;
import com.bean.Ingred;
import com.bean.Item;
import com.bean.Milk;
import com.bean.MilkType;
import com.bean.Wheat;
import com.bean.WheatType;
import com.exception.NoDataFoundException;
import com.psl.ExpiryDateComparator;

// Override and implement all the methods of DBConnectionUtil Interface in this class
public class InventoryServiceImpl implements InventoryService {

	private static List<Item> itemList = new CopyOnWriteArrayList<>();
	private static List<Cheese> cheeseList = new CopyOnWriteArrayList<>();
	private static List<Milk> milkList = new CopyOnWriteArrayList<>();
	private static List<Wheat> wheatList = new CopyOnWriteArrayList<>();
	
	@Override
	public List<Item> readAllItemsFromDb() {
		
		DatabaseConnectionManager manager = new DatabaseConnectionManager();
		
		try {
			Connection con = manager.getConnection();
					
			String query = "select * from cheese_tbl;";
			Statement st = con.createStatement();
			
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next())
			{
				Item i = new Item();
				i.setId(rs.getInt(1));
				i.setDescription(rs.getString(2));
				i.setWeight(rs.getFloat(3));
				i.setPrice(rs.getFloat(4));
				i.setManufacturingDate(rs.getDate(5));
				i.setUseBeforeMonths(rs.getInt(6));
				
				itemList.add(i);
				
				Cheese c = new Cheese();
				c.setCheeseType(CheeseType.valueOf(rs.getString(7)));
				Map<Ingred,Float> m = new HashMap<>();
				m.put(Ingred.valueOf("protein"), rs.getFloat(8));
				m.put(Ingred.valueOf("vitamin"), rs.getFloat(9));
				m.put(Ingred.valueOf("fat"), rs.getFloat(10));
				
				c.setCalorieTable(m);
				
				cheeseList.add(c);
			}
			
			String query2 = "select * from milk_tbl;";
			Statement st2 = con.createStatement();
			
			ResultSet rs2 = st2.executeQuery(query2);
			
			while(rs2.next())
			{
				Item i = new Item();
				i.setId(rs2.getInt(1));
				i.setDescription(rs2.getString(2));
				i.setWeight(rs2.getFloat(3));
				i.setPrice(rs2.getFloat(4));
				i.setManufacturingDate(rs2.getDate(5));
				i.setUseBeforeMonths(rs2.getInt(6));
				
				itemList.add(i);
				
				Milk c = new Milk();
				c.setFatRate(rs2.getFloat(7));
				
				c.setMilkpacket(MilkType.valueOf(rs2.getString(8)));
				
				milkList.add(c);
			}
			
			String query3 = "select * from wheat_tbl;";
			Statement st3 = con.createStatement();
			
			
			ResultSet rs3 = st3.executeQuery(query3);
			
			while(rs3.next())
			{
				Item i = new Item();
				i.setId(rs3.getInt(1));
				i.setDescription(rs3.getString(2));
				i.setWeight(rs3.getFloat(3));
				i.setPrice(rs3.getFloat(4));
				i.setManufacturingDate(rs3.getDate(5));
				i.setUseBeforeMonths(rs3.getInt(6));
				
				itemList.add(i);
				
				Wheat c = new Wheat();
				c.setWheatType(WheatType.valueOf(rs3.getString(7)));
							
				wheatList.add(c);
			}
		
			manager.closeConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return itemList;
	}

	@Override
	public void calculateExpiryDate(List<Item> items) {
		
		for(Item i : items)
		{
			Date d = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(i.getManufacturingDate());
			cal.add(Calendar.MONTH, i.getUseBeforeMonths());
			d = cal.getTime();
			
			java.sql.Date sql1 = new java.sql.Date(d.getTime());
			i.setExpiryDate(sql1);
		}
		
	}

	@Override
	public void removeExpiredItems(List<Item> items) {
		
		for(int i=0; i<items.size(); i++)
		{
			Date d = Calendar.getInstance().getTime();
			if((items.get(i).getExpiryDate()).before(d))
			{
				
				items.remove(i);
			}
		}	
		
	}

	@Override
	public void sortItems(List<Item> items) {
		// TODO Auto-generated method stub
		
		items.sort(new ExpiryDateComparator());
		
		for(Item i : items)
		{
			System.out.println(i);
		}
			
	}

	@Override
	public void applyDiscount(List<Item> items) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 2);
		Date d = cal.getTime();
				
		for(Item i : items)
		{
			if(i.getExpiryDate().before(d))
			{
				float disc = (float) (0.2*i.getPrice());
				i.setPrice(i.getPrice()-disc); 
				
			}
		}
		
	}

	@Override
	public List<Item> searchItem(String ItemType, List<Item> list)
			throws NoDataFoundException {
		int count = 0;
		List<Item> searcheditem = new ArrayList<>();
		for(Item i : list)
		{
			if(i.getDescription().contains(ItemType))
			{
				searcheditem.add(i);
				
				count++;
			}
		}
		if(count==0)
			throw new NoDataFoundException();
		return searcheditem;
	}
		
}
