package com.psl;

import java.util.Comparator;
import java.util.Date;

import com.bean.Item;

public class ExpiryDateComparator implements Comparator<Item>{

	@Override
	public int compare(Item arg0, Item arg1) {
		Date d1 = arg0.getExpiryDate();
		Date d2 = arg1.getExpiryDate();
		return d2.compareTo(d1);
	}

}
