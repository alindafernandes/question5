package com.psl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.bean.Item;
import com.exception.NoDataFoundException;
import com.util.DatabaseConnectionManager;
import com.util.InventoryServiceImpl;

public class Client {

	
	public static void main(String[] args) {
		
		
		InventoryServiceImpl inv = new InventoryServiceImpl();
		List<Item> list = inv.readAllItemsFromDb();
	
		inv.calculateExpiryDate(list);
		
		inv.removeExpiredItems(list);
		
		inv.sortItems(list);
		
		inv.applyDiscount(list);
		
		try {
			List<Item> l = inv.searchItem("buffalo", list);
		} catch (NoDataFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
}
